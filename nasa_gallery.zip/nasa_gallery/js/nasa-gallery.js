jQuery(document).ready(function($) {
       $(".nasa-gallery").slick({
                autoplay: true,
                autoplaySpeed: 4000
       });         
});


